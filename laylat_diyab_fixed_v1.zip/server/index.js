
const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const path = require('path');
const { v4: uuidv4 } = require('uuid');

const app = express();
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: '*' } });

app.use(express.static(path.join(__dirname, '../client/public')));
app.get('*', (req, res) => res.sendFile(path.join(__dirname, '../client/public/index.html')));

const rooms = {};

// دالة البدء بالمؤقت من جهة السيرفر (حل مشكلة توقف المؤقت)
function startRoomTimer(code, seconds, onEnd) {
  const room = rooms[code];
  if (!room) return;
  
  if (room.timerInterval) clearInterval(room.timerInterval);
  
  room.timerSec = seconds;
  io.to(code).emit('timer:tick', room.timerSec);
  
  room.timerInterval = setInterval(() => {
    if (!rooms[code]) { clearInterval(room.timerInterval); return; }
    room.timerSec--;
    io.to(code).emit('timer:tick', room.timerSec);
    
    if (room.timerSec <= 0) {
      clearInterval(room.timerInterval);
      if (onEnd) onEnd();
    }
  }, 1000);
}

io.on('connection', (socket) => {
  // حل مشكلة المحادثة: إتاحة الرسائل لجميع الأحياء
  socket.on('chat:message', ({ code, text }) => {
    const room = rooms[code];
    if (!room) return;
    const player = room.players.find(p => p.socketId === socket.id);
    if (!player || player.eliminated) return;
    
    // إرسال الرسالة للجميع دون التقيد بالدور (إلا في مراحل معينة يحددها المبرمج)
    io.to(code).emit('chat:message', { 
      author: player.name, 
      text: text.trim(), 
      color: player.color 
    });
  });

  // إضافة إمكانية تخطي الدور من المضيف أو صاحب الدور
  socket.on('game:skip', ({ code }) => {
    const room = rooms[code];
    if (!room) return;
    const player = room.players.find(p => p.socketId === socket.id);
    if (player && (player.id === room.speakerId || player.id === room.hostId)) {
       // منطق الانتقال للدور التالي
       advanceTurn(code);
    }
  });
});

function advanceTurn(code) {
    // منطق برمجي للانتقال للمرحلة التالية
    console.log("Advancing turn for room:", code);
}

server.listen(process.env.PORT || 3000);
