const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const { v4: uuidv4 } = require('uuid'); // استخدام uuid بناءً على ملف package.json[cite: 2]

const app = express();
const server = http.createServer(app);
const io = new Server(server, {
    cors: { origin: "*" }
});

// إعدادات اللعبة
let players = {};
let gamePhase = 'waiting'; // waiting, night, day, voting
let timer = null;
let timeLeft = 0;

io.on('connection', (socket) => {
    console.log('لاعب جديد اتصل:', socket.id);

    socket.on('join-game', (username) => {
        players[socket.id] = {
            id: socket.id,
            username: username,
            role: null,
            isAlive: true,
            votes: 0
        };
        io.emit('update-players', Object.values(players));
    });

    // --- نظام المؤقت المركزي (حل مشكلة توقف اللعبة) ---
    socket.on('start-game', () => {
        if (Object.keys(players).length >= 4) { // الحد الأدنى للعب
            assignRoles();
            startPhase('night', 30);
        }
    });

    socket.on('send-message', (message) => {
        const player = players[socket.id];
        // حل مشكلة المحادثة: السماح للجميع بالكلام في النهار إذا كانوا أحياء
        if (player && player.isAlive) {
            if (gamePhase === 'day' || gamePhase === 'voting') {
                io.emit('new-message', {
                    username: player.username,
                    text: message
                });
            } else if (gamePhase === 'night' && player.role === 'wolf') {
                // محادثة خاصة بالذئاب فقط في الليل
                const wolves = Object.values(players).filter(p => p.role === 'wolf');
                wolves.forEach(wolf => {
                    io.to(wolf.id).emit('new-message', {
                        username: `(ذئب) ${player.username}`,
                        text: message
                    });
                });
            }
        }
    });

    socket.on('disconnect', () => {
        delete players[socket.id];
        io.emit('update-players', Object.values(players));
    });
});

// دالة إدارة أطوار اللعبة والمؤقت
function startPhase(phase, duration) {
    gamePhase = phase;
    timeLeft = duration;
    io.emit('phase-change', { phase, duration });

    if (timer) clearInterval(timer);

    timer = setInterval(() => {
        timeLeft--;
        io.emit('timer-update', timeLeft);

        if (timeLeft <= 0) {
            clearInterval(timer);
            nextPhase();
        }
    }, 1000);
}

function nextPhase() {
    if (gamePhase === 'night') startPhase('day', 60);
    else if (gamePhase === 'day') startPhase('voting', 30);
    else if (gamePhase === 'voting') startPhase('night', 30);
}

function assignRoles() {
    const ids = Object.keys(players);
    const wolfCount = Math.floor(ids.length / 3);
    const shuffled = ids.sort(() => 0.5 - Math.random());

    shuffled.forEach((id, index) => {
        players[id].role = index < wolfCount ? 'wolf' : 'villager';
        io.to(id).emit('your-role', players[id].role);
    });
}

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
    console.log(`سيرفر ليلة الذياب يعمل على المنفذ ${PORT}`);
});