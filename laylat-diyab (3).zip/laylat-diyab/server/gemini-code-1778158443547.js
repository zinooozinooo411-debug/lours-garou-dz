const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const path = require('path');
const { v4: uuidv4 } = require('uuid');

const app = express();
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: '*' } });

app.use(express.static(path.join(__dirname, '../client/public')));
app.get('*', (req, res) => res.sendFile(path.join(__dirname, '../client/public/index.html')));

const rooms = {};

// دالة البدء بالعد التنازلي المركزي (إصلاح مشكلة توقف اللعبة)
function startRoomTimer(code, duration, nextPhaseFunc) {
  const room = rooms[code];
  if (!room) return;
  
  room.timeLeft = duration;
  if (room.timer) clearInterval(room.timer);

  room.timer = setInterval(() => {
    room.timeLeft--;
    io.to(code).emit('timer:update', { timeLeft: room.timeLeft });

    if (room.timeLeft <= 0) {
      clearInterval(room.timer);
      nextPhaseFunc(code); // الانتقال للمرحلة التالية تلقائياً
    }
  }, 1000);
}

io.on('connection', (socket) => {
  // عند دخول لاعب
  socket.on('room:join', ({ code, name }) => {
    const roomCode = code.toUpperCase();
    if (!rooms[roomCode]) return socket.emit('error', 'الغرفة غير موجودة');
    
    socket.join(roomCode);
    const p = { id: uuidv4(), socketId: socket.id, name, isAlive: true, role: 'civilian' };
    rooms[roomCode].players.push(p);
    io.to(roomCode).emit('room:update', rooms[roomCode]);
  });

  // إصلاح المحادثة: السماح بالرسائل للجميع في النهار
  socket.on('chat:message', ({ code, text }) => {
    const room = rooms[code];
    if (!room) return;
    const p = room.players.find(x => x.socketId === socket.id);
    
    if (p && p.isAlive) {
      // إرسال الرسالة للجميع إذا كان الوقت نهاراً أو وقت تصويت
      if (room.phase === 'day' || room.phase === 'voting') {
        io.to(code).emit('chat:message', { author: p.name, text });
      } 
      // محادثة الذئاب السرية في الليل
      else if (room.phase === 'night' && p.role === 'wolf') {
        room.players.filter(x => x.role === 'wolf').forEach(w => {
          io.to(w.socketId).emit('chat:message', { author: `[ذئب] ${p.name}`, text });
        });
      }
    }
  });

  socket.on('disconnect', () => {
    // منطق الخروج وتنظيف الغرفة
  });
});

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => console.log(`Game running on port ${PORT}`));